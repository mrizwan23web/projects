// File: js/contact.js

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("contactForm");
  const status = document.getElementById("form-status");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const message = form.message.value.trim();

    if (name === "" || email === "" || message === "") {
      status.style.color = "red";
      status.textContent = "Please fill out all fields.";
      return;
    }

    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      status.style.color = "red";
      status.textContent = "Please enter a valid email address.";
      return;
    }

    status.style.color = "green";
    status.textContent = "Your message has been sent successfully! (Dummy)";
    form.reset();
  });
});
